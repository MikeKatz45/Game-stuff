﻿Public Class Form1

    Private Sub PictureBox1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox1.Hide()
            PictureBox24.Show()
        End If

    End Sub

    Private Sub PictureBox2_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox2.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox2.Hide()
            PictureBox25.Show()
        End If

    End Sub

    Private Sub PictureBox3_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox3.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox3.Hide()
            PictureBox26.Show()
        End If

    End Sub

    Private Sub PictureBox4_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox4.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox4.Hide()
            PictureBox27.Show()
        End If

    End Sub

    Private Sub PictureBox5_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox5.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox5.Hide()
            PictureBox28.Show()
        End If

    End Sub

    Private Sub PictureBox6_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox6.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox6.Hide()
            PictureBox29.Show()
        End If

    End Sub

    Private Sub PictureBox7_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox7.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox7.Hide()
            PictureBox30.Show()
        End If

    End Sub

    Private Sub PictureBox8_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox8.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox8.Hide()
            PictureBox31.Show()
        End If

    End Sub

    Private Sub PictureBox9_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox9.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox9.Hide()
            PictureBox32.Show()
        End If

    End Sub

    Private Sub PictureBox10_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox10.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox10.Hide()
            PictureBox33.Show()
        End If

    End Sub

    Private Sub PictureBox11_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox11.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox11.Hide()
            PictureBox34.Show()
        End If

    End Sub

    Private Sub PictureBox12_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox12.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox12.Hide()
            PictureBox35.Show()
        End If

    End Sub

    Private Sub PictureBox13_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox13.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox13.Hide()
            PictureBox36.Show()
        End If

    End Sub

    Private Sub PictureBox14_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox14.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox14.Hide()
            PictureBox37.Show()
        End If

    End Sub

    Private Sub PictureBox15_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox15.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox15.Hide()
            PictureBox38.Show()
        End If

    End Sub

    Private Sub PictureBox16_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox16.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox16.Hide()
            PictureBox39.Show()
        End If

    End Sub

    Private Sub PictureBox17_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox17.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox17.Hide()
            PictureBox40.Show()
        End If

    End Sub

    Private Sub PictureBox18_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox18.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox18.Hide()
            PictureBox41.Show()
        End If

    End Sub

    Private Sub PictureBox19_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox19.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox19.Hide()
            PictureBox42.Show()
        End If

    End Sub

    Private Sub PictureBox20_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox20.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox20.Hide()
            PictureBox43.Show()
        End If

    End Sub

    Private Sub PictureBox21_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox21.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox21.Hide()
            PictureBox44.Show()
        End If

    End Sub

    Private Sub PictureBox22_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox22.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox22.Hide()
            PictureBox45.Show()
        End If

    End Sub

    Private Sub PictureBox23_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox23.MouseDown

        If e.Button = MouseButtons.Left Then
            PictureBox23.Hide()
            PictureBox46.Show()
        End If

    End Sub

    Private Sub PictureBox24_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox24.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox24.Hide()
            PictureBox1.Show()
        End If

    End Sub

    Private Sub PictureBox25_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox25.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox25.Hide()
            PictureBox2.Show()
        End If

    End Sub

    Private Sub PictureBox26_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox26.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox26.Hide()
            PictureBox3.Show()
        End If

    End Sub

    Private Sub PictureBox27_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox27.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox27.Hide()
            PictureBox4.Show()
        End If

    End Sub

    Private Sub PictureBox28_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox28.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox28.Hide()
            PictureBox5.Show()
        End If

    End Sub

    Private Sub PictureBox29_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox29.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox29.Hide()
            PictureBox6.Show()
        End If

    End Sub

    Private Sub PictureBox30_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox30.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox30.Hide()
            PictureBox7.Show()
        End If

    End Sub

    Private Sub PictureBox31_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox31.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox31.Hide()
            PictureBox8.Show()
        End If

    End Sub

    Private Sub PictureBox32_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox32.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox32.Hide()
            PictureBox9.Show()
        End If

    End Sub

    Private Sub PictureBox33_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox33.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox33.Hide()
            PictureBox10.Show()
        End If

    End Sub

    Private Sub PictureBox34_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox34.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox34.Hide()
            PictureBox11.Show()
        End If

    End Sub

    Private Sub PictureBox35_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox35.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox35.Hide()
            PictureBox12.Show()
        End If

    End Sub

    Private Sub PictureBox36_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox36.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox36.Hide()
            PictureBox13.Show()
        End If

    End Sub

    Private Sub PictureBox37_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox37.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox37.Hide()
            PictureBox14.Show()
        End If

    End Sub

    Private Sub PictureBox38_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox38.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox38.Hide()
            PictureBox15.Show()
        End If

    End Sub

    Private Sub PictureBox39_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox39.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox39.Hide()
            PictureBox16.Show()
        End If

    End Sub

    Private Sub PictureBox40_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox40.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox40.Hide()
            PictureBox17.Show()
        End If

    End Sub

    Private Sub PictureBox41_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox41.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox41.Hide()
            PictureBox18.Show()
        End If

    End Sub

    Private Sub PictureBox42_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox42.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox42.Hide()
            PictureBox19.Show()
        End If

    End Sub

    Private Sub PictureBox43_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox43.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox43.Hide()
            PictureBox20.Show()
        End If

    End Sub

    Private Sub PictureBox44_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox44.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox44.Hide()
            PictureBox21.Show()
        End If

    End Sub

    Private Sub PictureBox45_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox45.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox45.Hide()
            PictureBox22.Show()
        End If

    End Sub

    Private Sub PictureBox46_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox46.MouseDown

        If e.Button = MouseButtons.Right Then
            PictureBox46.Hide()
            PictureBox23.Show()
        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        PictureBox24.Hide()
        PictureBox25.Hide()
        PictureBox26.Hide()
        PictureBox27.Hide()
        PictureBox28.Hide()
        PictureBox29.Hide()
        PictureBox30.Hide()
        PictureBox31.Hide()
        PictureBox32.Hide()
        PictureBox33.Hide()
        PictureBox34.Hide()
        PictureBox35.Hide()
        PictureBox36.Hide()
        PictureBox37.Hide()
        PictureBox38.Hide()
        PictureBox39.Hide()
        PictureBox40.Hide()
        PictureBox41.Hide()
        PictureBox42.Hide()
        PictureBox43.Hide()
        PictureBox44.Hide()
        PictureBox45.Hide()
        PictureBox46.Hide()

        PictureBox1.Show()
        PictureBox2.Show()
        PictureBox3.Show()
        PictureBox4.Show()
        PictureBox5.Show()
        PictureBox6.Show()
        PictureBox7.Show()
        PictureBox8.Show()
        PictureBox9.Show()
        PictureBox10.Show()
        PictureBox11.Show()
        PictureBox12.Show()
        PictureBox13.Show()
        PictureBox14.Show()
        PictureBox15.Show()
        PictureBox16.Show()
        PictureBox17.Show()
        PictureBox18.Show()
        PictureBox19.Show()
        PictureBox20.Show()
        PictureBox21.Show()
        PictureBox22.Show()
        PictureBox23.Show()
    End Sub
End Class

